using System.Collections.Generic;

namespace KvalikBlazor.Model
{
    public class GroupModelDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ProgramTitle { get; set; }
        public string TeacherName { get; set; }
        public List<UserProfileModel> Students { get; set; } = new List<UserProfileModel>();
    }
} 