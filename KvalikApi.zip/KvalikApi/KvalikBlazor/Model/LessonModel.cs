using System;
using System.Collections.Generic;

namespace KvalikBlazor.Model
{
    public class LessonModel
    {
        public int Id { get; set; }
        public int? GroupId { get; set; }
        public string GroupName { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int? ThemeId { get; set; }
        public DateTime? DateTime { get; set; }
        public DateTime? Date { get; set; }
        public List<MaterialModel> Materials { get; set; }
        public List<CommentModel> Comments { get; set; }
    }
} 