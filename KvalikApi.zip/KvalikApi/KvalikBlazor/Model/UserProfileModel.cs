using System;

namespace KvalikBlazor.Model
{
    public class UserProfileModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public DateTime? JoinDate { get; set; }
    }
} 