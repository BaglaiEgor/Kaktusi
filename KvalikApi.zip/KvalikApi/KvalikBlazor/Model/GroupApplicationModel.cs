using System;

namespace KvalikBlazor.Model
{
    public class GroupApplicationModel
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int GroupId { get; set; }
        public string Status { get; set; } // "Заявка подана", "Одобрено", "Отклонено"
        public DateTime CreatedAt { get; set; }
        public DateTime? ReviewedAt { get; set; }
        
        // Дополнительные свойства для отображения
        public string StudentName { get; set; }
        public string GroupName { get; set; }
        public string ProgramTitle { get; set; }
        public string TeacherName { get; set; }
    }
} 