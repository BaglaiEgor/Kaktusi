using System.ComponentModel.DataAnnotations;

namespace KvalikBlazor.Model
{
    public class RegisterModel
    {
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        [MaxLength(100)]
        public string Email { get; set; }
        [Required]
        [MinLength(6)]
        public string Password { get; set; }
        [Required]
        [MaxLength(20)]
        public string Role { get; set; } = "Student";
    }
} 