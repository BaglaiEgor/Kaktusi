using System;

namespace KvalikBlazor.Model
{
    public class AttendanceModel
    {
        public int Id { get; set; }
        public int LessonId { get; set; }
        public int StudentId { get; set; }
        public bool IsPresent { get; set; }
        public string LessonTitle { get; set; }
        public string StudentName { get; set; }
        public DateTime? LessonDateTime { get; set; }
        public string GroupName { get; set; }
        public DateTime? Date { get; set; }
    }
} 