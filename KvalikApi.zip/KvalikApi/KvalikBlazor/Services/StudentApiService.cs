using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using KvalikBlazor.Model;
using System.Linq;
using System;

namespace KvalikBlazor.Services
{
    public class StudentApiService
    {
        private readonly HttpClient _http;
        public StudentApiService(HttpClient http)
        {
            _http = http;
        }

        public async Task<UserProfileModel> GetProfileAsync(int userId)
            => await _http.GetFromJsonAsync<UserProfileModel>($"api/users/{userId}");

        public async Task<(bool Success, string ErrorMessage)> UpdateProfileAsync(UserProfileModel profile)
        {
            try
            {
                var response = await _http.PutAsJsonAsync($"api/users/{profile.Id}", profile);
                if (response.IsSuccessStatusCode)
                    return (true, null);
                var error = await response.Content.ReadAsStringAsync();
                return (false, error);
            }
            catch (Exception ex)
            {
                return (false, ex.Message);
            }
        }

        public async Task<IEnumerable<GroupModelDto>> GetAvailableGroupsAsync()
            => await _http.GetFromJsonAsync<IEnumerable<GroupModelDto>>("api/groups");

        public async Task<(bool Success, string ErrorMessage)> JoinGroupAsync(int groupId, int studentId)
        {
            var response = await _http.PostAsync($"api/groups/{groupId}/students/{studentId}", null);
            if (response.IsSuccessStatusCode)
                return (true, null);
            var error = await response.Content.ReadAsStringAsync();
            return (false, error);
        }

        public async Task<IEnumerable<GroupModelDto>> GetMyGroupsAsync(int userId)
        {
            try
            {
                return await _http.GetFromJsonAsync<IEnumerable<GroupModelDto>>($"api/groups/user/{userId}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get user groups: {ex.Message}");
            }
        }

        public async Task<IEnumerable<LessonModel>> GetScheduleAsync(int groupId)
        {
            try
            {
                Console.WriteLine($"Запрашиваем уроки для группы {groupId}");
                var result = await _http.GetFromJsonAsync<IEnumerable<LessonModel>>($"api/Groups/{groupId}/schedule");
                Console.WriteLine($"Получено уроков: {result?.Count() ?? 0}");
                
                if (result != null)
                {
                    // Маппим DateTime в Date для совместимости с фронтендом
                    foreach (var lesson in result)
                    {
                        lesson.Date = lesson.DateTime;
                        Console.WriteLine($"Урок: {lesson.Title}, DateTime: {lesson.DateTime}, Date: {lesson.Date}");
                    }
                }
                return result ?? new List<LessonModel>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка получения расписания: {ex.Message}");
                throw new Exception($"Failed to get schedule: {ex.Message}");
            }
        }

        public async Task<LessonModel> GetLessonAsync(int lessonId)
            => await _http.GetFromJsonAsync<LessonModel>($"api/lessons/{lessonId}");

        public async Task<bool> MarkLessonCompletedAsync(int studentId, int lessonId, int teacherId)
        {
            var response = await _http.PostAsync($"api/progress/complete?studentId={studentId}&lessonId={lessonId}&teacherId={teacherId}", null);
            return response.IsSuccessStatusCode;
        }

        public async Task<IEnumerable<ProgressModel>> GetProgressAsync(int studentId)
            => await _http.GetFromJsonAsync<IEnumerable<ProgressModel>>($"api/progress/by-student/{studentId}");

        public async Task<IEnumerable<ChatMessageModel>> GetLessonChatAsync(int lessonId)
            => await _http.GetFromJsonAsync<IEnumerable<ChatMessageModel>>($"api/chat/by-lesson/{lessonId}");

        public async Task<bool> SendChatMessageAsync(CreateChatMessageDto messageDto)
        {
            try
            {
                Console.WriteLine($"StudentApiService.SendChatMessageAsync: отправляем сообщение LessonId={messageDto.LessonId}, AuthorId={messageDto.AuthorId}");
                var response = await _http.PostAsJsonAsync("api/chat", messageDto);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"StudentApiService.SendChatMessageAsync: ошибка {response.StatusCode} - {errorContent}");
                }
                
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"StudentApiService.SendChatMessageAsync: исключение - {ex.Message}");
                throw new Exception($"Failed to send chat message: {ex.Message}");
            }
        }

        public async Task<bool> MarkAttendanceAsync(int lessonId, int studentId, bool isPresent)
        {
            var response = await _http.PostAsync($"api/attendance?lessonId={lessonId}&studentId={studentId}&isPresent={isPresent}", null);
            return response.IsSuccessStatusCode;
        }

        public async Task<IEnumerable<AttendanceModel>> GetAttendanceByStudentAsync(int studentId)
        {
            try
            {
                return await _http.GetFromJsonAsync<IEnumerable<AttendanceModel>>($"api/attendance/by-student/{studentId}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get attendance: {ex.Message}");
            }
        }

        public async Task<IEnumerable<AttendanceModel>> GetAttendanceByLessonAsync(int lessonId)
        {
            try
            {
                return await _http.GetFromJsonAsync<IEnumerable<AttendanceModel>>($"api/attendance/by-lesson/{lessonId}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get lesson attendance: {ex.Message}");
            }
        }

        public async Task<GroupApplicationModel> CreateGroupApplicationAsync(int groupId, int studentId)
        {
            var response = await _http.PostAsync($"api/GroupApplications?groupId={groupId}&studentId={studentId}", null);
            if (!response.IsSuccessStatusCode)
                throw new Exception(await response.Content.ReadAsStringAsync());
            return await response.Content.ReadFromJsonAsync<GroupApplicationModel>();
        }

        public async Task<GroupApplicationModel> GetGroupApplicationAsync(int groupId, int studentId)
        {
            var apps = await GetUserApplicationsAsync(studentId);
            return apps?.FirstOrDefault(a => a.GroupId == groupId && a.Status == "Заявка подана");
        }

        public async Task<List<GroupApplicationModel>> GetUserApplicationsAsync(int studentId)
        {
            var result = await _http.GetFromJsonAsync<List<GroupApplicationModel>>($"api/GroupApplications/by-user/{studentId}");
            return result ?? new List<GroupApplicationModel>();
        }

        // Методы для учителей
        public async Task<List<LessonModel>> GetTeacherLessonsAsync(int teacherId)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<LessonModel>>($"api/lessons/by-teacher/{teacherId}");
                return result ?? new List<LessonModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get teacher lessons: {ex.Message}");
            }
        }

        public async Task<List<LessonModel>> GetGroupLessonsAsync(int groupId)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<LessonModel>>($"api/groups/{groupId}/schedule");
                if (result != null)
                {
                    // Маппим DateTime в Date для совместимости с фронтендом
                    foreach (var lesson in result)
                    {
                        lesson.Date = lesson.DateTime;
                    }
                }
                return result?.ToList() ?? new List<LessonModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get group lessons: {ex.Message}");
            }
        }

        public async Task<bool> CreateLessonAsync(LessonModel lesson)
        {
            try
            {
                var lessonData = new
                {
                    lesson.Title,
                    lesson.Description,
                    ThemeId = lesson.ThemeId ?? 0,
                    GroupId = lesson.GroupId ?? 0,
                    DateTime = lesson.Date ?? DateTime.Now
                };
                
                var response = await _http.PostAsJsonAsync("api/lessons", lessonData);
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Server error: {response.StatusCode} - {errorContent}");
                }
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to create lesson: {ex.Message}");
            }
        }

        public async Task<List<ThemeModel>> GetThemesAsync()
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<ThemeModel>>("api/themes");
                return result ?? new List<ThemeModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get themes: {ex.Message}");
            }
        }

        // Методы для управления группой
        public async Task<List<AttendanceModel>> GetAttendanceByGroupAsync(int groupId)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<AttendanceModel>>($"api/attendance/by-group/{groupId}");
                return result ?? new List<AttendanceModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get group attendance: {ex.Message}");
            }
        }

        public async Task<bool> RemoveStudentFromGroupAsync(int groupId, int studentId)
        {
            try
            {
                var response = await _http.DeleteAsync($"api/groups/{groupId}/students/{studentId}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to remove student from group: {ex.Message}");
            }
        }

        public async Task<bool> CreateAttendanceRecordAsync(int lessonId, int studentId, bool isPresent)
        {
            try
            {
                var response = await _http.PostAsync($"api/attendance?lessonId={lessonId}&studentId={studentId}&isPresent={isPresent}", null);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to create attendance record: {ex.Message}");
            }
        }

        public async Task<bool> UpdateAttendanceRecordAsync(int attendanceId, bool isPresent)
        {
            try
            {
                var response = await _http.PutAsync($"api/attendance/{attendanceId}?isPresent={isPresent}", null);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to update attendance record: {ex.Message}");
            }
        }

        public async Task<bool> AddMaterialAsync(MaterialModel material)
        {
            try
            {
                var response = await _http.PostAsJsonAsync("api/materials", material);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to add material: {ex.Message}");
            }
        }

        public async Task<bool> DeleteMaterialAsync(int materialId)
        {
            try
            {
                var response = await _http.DeleteAsync($"api/materials/{materialId}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to delete material: {ex.Message}");
            }
        }

        public async Task<List<MaterialModel>> GetLessonMaterialsAsync(int lessonId)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<MaterialModel>>($"api/materials/by-lesson/{lessonId}");
                return result ?? new List<MaterialModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get lesson materials: {ex.Message}");
            }
        }
    }
} 