using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using KvalikBlazor.Model;
using System.Linq;
using System;

namespace KvalikBlazor.Services
{
    public class TeacherApiService
    {
        private readonly HttpClient _http;
        public TeacherApiService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<GroupApplicationModel>> GetTeacherApplicationsAsync(int teacherId)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<GroupApplicationModel>>($"api/GroupApplications/by-teacher/{teacherId}");
                return result ?? new List<GroupApplicationModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get teacher applications: {ex.Message}");
            }
        }

        public async Task<bool> UpdateApplicationStatusAsync(int applicationId, string status)
        {
            var response = await _http.PutAsync($"api/GroupApplications/{applicationId}/status?status={status}", null);
            return response.IsSuccessStatusCode;
        }

        public async Task<IEnumerable<GroupModelDto>> GetTeacherGroupsAsync(int teacherId)
        {
            try
            {
                return await _http.GetFromJsonAsync<IEnumerable<GroupModelDto>>($"api/groups/user/{teacherId}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get teacher groups: {ex.Message}");
            }
        }

        public async Task<IEnumerable<LessonModel>> GetTeacherLessonsAsync(int teacherId)
        {
            try
            {
                return await _http.GetFromJsonAsync<IEnumerable<LessonModel>>($"api/lessons/by-teacher/{teacherId}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get teacher lessons: {ex.Message}");
            }
        }

        public async Task<LessonModel> GetLessonAsync(int lessonId)
        {
            return await _http.GetFromJsonAsync<LessonModel>($"api/lessons/{lessonId}");
        }

        public async Task<bool> MarkAttendanceAsync(int lessonId, int studentId, bool isPresent, int teacherId)
        {
            var response = await _http.PostAsync($"api/attendance?lessonId={lessonId}&studentId={studentId}&isPresent={isPresent}&teacherId={teacherId}", null);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> MarkLessonCompletedAsync(int studentId, int lessonId, int teacherId)
        {
            var response = await _http.PostAsync($"api/progress/complete?studentId={studentId}&lessonId={lessonId}&teacherId={teacherId}", null);
            return response.IsSuccessStatusCode;
        }

        public async Task<IEnumerable<AttendanceModel>> GetAttendanceByLessonAsync(int lessonId)
        {
            try
            {
                return await _http.GetFromJsonAsync<IEnumerable<AttendanceModel>>($"api/attendance/by-lesson/{lessonId}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get lesson attendance: {ex.Message}");
            }
        }

        public async Task<IEnumerable<ProgressModel>> GetProgressByGroupAsync(int groupId)
        {
            try
            {
                return await _http.GetFromJsonAsync<IEnumerable<ProgressModel>>($"api/progress/by-group/{groupId}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get group progress: {ex.Message}");
            }
        }

        public async Task<IEnumerable<ChatMessageModel>> GetLessonChatAsync(int lessonId)
        {
            return await _http.GetFromJsonAsync<IEnumerable<ChatMessageModel>>($"api/chat/by-lesson/{lessonId}");
        }

        public async Task<bool> SendChatMessageAsync(CreateChatMessageDto messageDto)
        {
            try
            {
                Console.WriteLine($"TeacherApiService.SendChatMessageAsync: отправляем сообщение LessonId={messageDto.LessonId}, AuthorId={messageDto.AuthorId}");
                var response = await _http.PostAsJsonAsync("api/chat", messageDto);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"TeacherApiService.SendChatMessageAsync: ошибка {response.StatusCode} - {errorContent}");
                }
                
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TeacherApiService.SendChatMessageAsync: исключение - {ex.Message}");
                throw new Exception($"Failed to send chat message: {ex.Message}");
            }
        }

        public async Task<bool> AddMaterialAsync(MaterialModel material)
        {
            try
            {
                Console.WriteLine($"TeacherApiService.AddMaterialAsync: отправляем материал с LessonId={material.LessonId}, Type={material.Type}");
                var response = await _http.PostAsJsonAsync("api/materials", material);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"TeacherApiService.AddMaterialAsync: ошибка сервера {response.StatusCode}: {errorContent}");
                }
                
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TeacherApiService.AddMaterialAsync: исключение: {ex.Message}");
                throw new Exception($"Failed to add material: {ex.Message}");
            }
        }

        public async Task<bool> DeleteMaterialAsync(int materialId)
        {
            try
            {
                Console.WriteLine($"TeacherApiService.DeleteMaterialAsync: удаляем материал с ID={materialId}");
                var response = await _http.DeleteAsync($"api/materials/{materialId}");
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"TeacherApiService.DeleteMaterialAsync: ошибка сервера {response.StatusCode}: {errorContent}");
                }
                
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TeacherApiService.DeleteMaterialAsync: исключение: {ex.Message}");
                throw new Exception($"Failed to delete material: {ex.Message}");
            }
        }

        public async Task<List<MaterialModel>> GetLessonMaterialsAsync(int lessonId)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<MaterialModel>>($"api/materials/by-lesson/{lessonId}");
                return result ?? new List<MaterialModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get lesson materials: {ex.Message}");
            }
        }

        public async Task<bool> AddCommentAsync(CreateCommentDto commentDto)
        {
            try
            {
                Console.WriteLine($"TeacherApiService.AddCommentAsync: отправляем запрос на api/comments");
                var response = await _http.PostAsJsonAsync("api/comments", commentDto);
                Console.WriteLine($"TeacherApiService.AddCommentAsync: получен ответ StatusCode={response.StatusCode}");
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"TeacherApiService.AddCommentAsync: ошибка - {errorContent}");
                }
                
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TeacherApiService.AddCommentAsync: исключение - {ex.Message}");
                throw new Exception($"Failed to add comment: {ex.Message}");
            }
        }

        public async Task<bool> DeleteCommentAsync(int commentId)
        {
            try
            {
                var response = await _http.DeleteAsync($"api/comments/{commentId}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to delete comment: {ex.Message}");
            }
        }

        public async Task<List<CommentModel>> GetLessonCommentsAsync(int lessonId)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<CommentModel>>($"api/comments/by-lesson/{lessonId}");
                return result ?? new List<CommentModel>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to get lesson comments: {ex.Message}");
            }
        }
    }
} 