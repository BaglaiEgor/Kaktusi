using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using KvalikBlazor.Model;

namespace KvalikBlazor.Services
{
    public class AuthApiService
    {
        private readonly HttpClient _http;
        public AuthApiService(HttpClient http)
        {
            _http = http;
        }

        public async Task<bool> RegisterAsync(RegisterModel model)
        {
            var response = await _http.PostAsJsonAsync("api/users/register", model);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> LoginAsync(LoginModel model)
        {
            var response = await _http.PostAsJsonAsync("api/users/login", model);
            return response.IsSuccessStatusCode;
        }

        public async Task<UserProfileModel> LoginAndGetUserAsync(LoginModel model)
        {
            var response = await _http.PostAsJsonAsync("api/users/login", model);
            if (response.IsSuccessStatusCode)
            {
                var user = await response.Content.ReadFromJsonAsync<UserProfileModel>();
                return user;
            }
            return null;
        }

        public async Task<(bool Success, string ErrorMessage)> RegisterWithErrorAsync(RegisterModel model)
        {
            var response = await _http.PostAsJsonAsync("api/users/register", model);
            if (response.IsSuccessStatusCode)
            {
                return (true, null);
            }
            else
            {
                var error = await response.Content.ReadAsStringAsync();
                return (false, error);
            }
        }
    }
} 