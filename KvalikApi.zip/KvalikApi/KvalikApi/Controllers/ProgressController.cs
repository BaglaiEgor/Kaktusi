using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProgressController : ControllerBase
    {
        private readonly IProgressService _progressService;
        public ProgressController(IProgressService progressService)
        {
            _progressService = progressService;
        }

        [HttpPost("complete")]
        public async Task<IActionResult> MarkCompleted([FromQuery] int studentId, [FromQuery] int lessonId)
        {
            var result = await _progressService.MarkLessonCompletedAsync(studentId, lessonId);
            return Ok(result);
        }

        [HttpGet("by-student/{studentId}")]
        public async Task<IActionResult> GetByStudent(int studentId)
        {
            var result = await _progressService.GetProgressByStudentAsync(studentId);
            return Ok(result);
        }

        [HttpGet("by-group/{groupId}")]
        public async Task<IActionResult> GetByGroup(int groupId)
        {
            var result = await _progressService.GetProgressByGroupAsync(groupId);
            return Ok(result);
        }
    }
} 