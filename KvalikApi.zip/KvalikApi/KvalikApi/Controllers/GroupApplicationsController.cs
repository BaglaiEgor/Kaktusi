using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GroupApplicationsController : ControllerBase
    {
        private readonly IGroupApplicationService _service;
        public GroupApplicationsController(IGroupApplicationService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromQuery] int groupId, [FromQuery] int studentId)
        {
            try
            {
                var app = await _service.CreateApplicationAsync(groupId, studentId);
                return Ok(app);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("by-user/{studentId}")]
        public async Task<IActionResult> GetByUser(int studentId)
        {
            var apps = await _service.GetApplicationsByUserAsync(studentId);
            return Ok(apps);
        }

        [HttpGet("by-group/{groupId}")]
        public async Task<IActionResult> GetByGroup(int groupId)
        {
            var apps = await _service.GetApplicationsByGroupAsync(groupId);
            return Ok(apps);
        }

        [HttpGet("by-teacher/{teacherId}")]
        public async Task<IActionResult> GetByTeacher(int teacherId)
        {
            var apps = await _service.GetApplicationsByTeacherAsync(teacherId);
            return Ok(apps);
        }

        [HttpPut("{applicationId}/status")]
        public async Task<IActionResult> UpdateStatus(int applicationId, [FromQuery] string status)
        {
            try
            {
                var app = await _service.UpdateStatusAsync(applicationId, status);
                return Ok(app);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
} 