using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ThemesController : ControllerBase
    {
        private readonly IThemeService _themeService;
        public ThemesController(IThemeService themeService)
        {
            _themeService = themeService;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Theme theme)
        {
            var created = await _themeService.CreateThemeAsync(theme);
            return Ok(new { created.Id, created.Title, created.ProgramId });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var theme = await _themeService.GetThemeByIdAsync(id);
            if (theme == null) return NotFound();
            return Ok(new { theme.Id, theme.Title, theme.ProgramId });
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var themes = await _themeService.GetAllThemesAsync();
            var dtos = themes.Select(t => new { t.Id, t.Title, t.ProgramId });
            return Ok(dtos);
        }

        [HttpPut]
        public async Task<IActionResult> Update([FromBody] Theme theme)
        {
            // Для обновления нужен Id
            return BadRequest("Id is required for update");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _themeService.DeleteThemeAsync(id);
            return NoContent();
        }
    }
} 