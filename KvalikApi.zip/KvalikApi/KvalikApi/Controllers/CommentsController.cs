using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CommentsController : ControllerBase
    {
        private readonly ICommentService _commentService;
        public CommentsController(ICommentService commentService)
        {
            _commentService = commentService;
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] CreateCommentDto commentDto)
        {
            try
            {
                Console.WriteLine($"CommentsController.Add вызван");
                Console.WriteLine($"Получен DTO: LessonId={commentDto.LessonId}, AuthorId={commentDto.AuthorId}, Text={commentDto.Text}");
                
                if (commentDto == null)
                {
                    Console.WriteLine("Ошибка: commentDto is null");
                    return BadRequest("CommentDto is null");
                }
                
                if (string.IsNullOrWhiteSpace(commentDto.Text))
                {
                    Console.WriteLine("Ошибка: Text is null or empty");
                    return BadRequest("Text is required");
                }
                
                if (commentDto.LessonId <= 0)
                {
                    Console.WriteLine("Ошибка: LessonId is invalid");
                    return BadRequest("LessonId is required");
                }
                
                if (commentDto.AuthorId <= 0)
                {
                    Console.WriteLine("Ошибка: AuthorId is invalid");
                    return BadRequest("AuthorId is required");
                }
                
                var result = await _commentService.AddCommentAsync(commentDto);
                Console.WriteLine($"Комментарий успешно добавлен с Id: {result.Id}");
                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка в CommentsController.Add: {ex.Message}");
                Console.WriteLine($"StackTrace: {ex.StackTrace}");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("by-lesson/{lessonId}")]
        public async Task<IActionResult> GetByLesson(int lessonId)
        {
            var result = await _commentService.GetCommentsByLessonAsync(lessonId);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _commentService.DeleteCommentAsync(id);
            return Ok(result);
        }
    }
} 