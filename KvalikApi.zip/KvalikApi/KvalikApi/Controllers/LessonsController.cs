using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LessonsController : ControllerBase
    {
        private readonly ILessonService _lessonService;
        public LessonsController(ILessonService lessonService)
        {
            _lessonService = lessonService;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateLessonDto lessonDto)
        {
            var lesson = new Lesson
            {
                Title = lessonDto.Title,
                Description = lessonDto.Description,
                ThemeId = lessonDto.ThemeId,
                GroupId = lessonDto.GroupId,
                DateTime = lessonDto.DateTime
            };
            
            var created = await _lessonService.CreateLessonAsync(lesson);
            return Ok(created);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var lesson = await _lessonService.GetLessonByIdDtoAsync(id);
            if (lesson == null) return NotFound();
            return Ok(lesson);
        }

        [HttpGet("group/{groupId}")]
        public async Task<IActionResult> GetByGroup(int groupId)
        {
            var lessons = await _lessonService.GetLessonsByGroupIdAsync(groupId);
            return Ok(lessons);
        }

        [HttpGet("by-teacher/{teacherId}")]
        public async Task<IActionResult> GetByTeacher(int teacherId)
        {
            var lessons = await _lessonService.GetLessonsByTeacherAsync(teacherId);
            return Ok(lessons);
        }

        [HttpPut]
        public async Task<IActionResult> Update([FromBody] Lesson lesson)
        {
            var updated = await _lessonService.UpdateLessonAsync(lesson);
            return Ok(updated);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _lessonService.DeleteLessonAsync(id);
            return NoContent();
        }

        [HttpPost("{lessonId}/materials")]
        public async Task<IActionResult> AddMaterial(int lessonId, [FromBody] Material material)
        {
            var result = await _lessonService.AddMaterialAsync(lessonId, material);
            return Ok(result);
        }

        [HttpPost("{lessonId}/comments")]
        public async Task<IActionResult> AddComment(int lessonId, [FromBody] Comment comment)
        {
            var result = await _lessonService.AddCommentAsync(lessonId, comment);
            return Ok(result);
        }

        [HttpPost("{lessonId}/attendance")]
        public async Task<IActionResult> MarkAttendance(int lessonId, [FromQuery] int studentId, [FromQuery] bool isPresent)
        {
            var result = await _lessonService.MarkAttendanceAsync(lessonId, studentId, isPresent);
            return Ok(result);
        }
    }
} 