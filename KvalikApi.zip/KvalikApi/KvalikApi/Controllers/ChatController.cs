using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChatController : ControllerBase
    {
        private readonly IChatService _chatService;
        public ChatController(IChatService chatService)
        {
            _chatService = chatService;
        }

        [HttpPost]
        public async Task<IActionResult> Send([FromBody] CreateChatMessageDto messageDto)
        {
            try
            {
                Console.WriteLine($"ChatController.Send: получено сообщение LessonId={messageDto.LessonId}, AuthorId={messageDto.AuthorId}, Text={messageDto.Text}");
                var result = await _chatService.SendMessageAsync(messageDto);
                Console.WriteLine($"ChatController.Send: сообщение сохранено с Id={result.Id}");
                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ChatController.Send: ошибка - {ex.Message}");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("by-lesson/{lessonId}")]
        public async Task<IActionResult> GetByLesson(int lessonId)
        {
            var result = await _chatService.GetMessagesByLessonAsync(lessonId);
            return Ok(result);
        }
    }
} 