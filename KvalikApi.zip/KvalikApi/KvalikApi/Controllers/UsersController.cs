using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Requests;
using System.Threading.Tasks;
using System.Linq;
using KvalikApi.Models;
using System.ComponentModel.DataAnnotations;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            try
            {
                var user = await _userService.RegisterDtoAsync(request.Name, request.Email, request.Password, request.Role);
                return Ok(user);
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var user = await _userService.LoginDtoAsync(request.Email, request.Password);
            if (user == null) return Unauthorized();
            return Ok(user);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var user = await _userService.GetUserByIdDtoAsync(id);
            if (user == null) return NotFound();
            return Ok(user);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var users = await _userService.GetAllUsersDtoAsync();
            return Ok(users);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UserDto userDto)
        {
            try
            {
                if (id != userDto.Id)
                    return BadRequest("ID в URL не совпадает с ID в теле запроса");

                var updatedUser = await _userService.UpdateUserAsync(id, userDto.Name, userDto.Email);
                return Ok(updatedUser);
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
} 