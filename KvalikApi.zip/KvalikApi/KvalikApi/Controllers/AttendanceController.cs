using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceService _attendanceService;
        private readonly ApplicationDbContext _context;
        
        public AttendanceController(IAttendanceService attendanceService, ApplicationDbContext context)
        {
            _attendanceService = attendanceService;
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> MarkAttendance([FromQuery] int lessonId, [FromQuery] int studentId, [FromQuery] bool isPresent, [FromQuery] int teacherId)
        {
            // Проверяем роль преподавателя
            var teacher = await _context.Users.FirstOrDefaultAsync(u => u.Id == teacherId);
            if (teacher == null)
                return BadRequest("Преподаватель не найден");
            
            if (teacher.Role != "Teacher")
                return BadRequest("Только преподаватели могут отмечать посещаемость");

            // Проверяем, что преподаватель ведет группу этого урока
            var lesson = await _context.Lessons
                .Include(l => l.Group)
                .FirstOrDefaultAsync(l => l.Id == lessonId);
            
            if (lesson == null)
                return BadRequest("Урок не найден");
            
            if (lesson.Group?.TeacherId != teacherId)
                return BadRequest("Вы не являетесь преподавателем этой группы");

            var result = await _attendanceService.MarkAttendanceAsync(lessonId, studentId, isPresent);
            return Ok(result);
        }

        [HttpGet("by-lesson/{lessonId}")]
        public async Task<IActionResult> GetByLesson(int lessonId)
        {
            var result = await _attendanceService.GetAttendanceByLessonAsync(lessonId);
            return Ok(result);
        }

        [HttpGet("by-student/{studentId}")]
        public async Task<IActionResult> GetByStudent(int studentId)
        {
            var result = await _attendanceService.GetAttendanceByStudentAsync(studentId);
            return Ok(result);
        }

        [HttpGet("by-group/{groupId}")]
        public async Task<IActionResult> GetByGroup(int groupId)
        {
            var result = await _attendanceService.GetAttendanceByGroupAsync(groupId);
            return Ok(result);
        }
    }
} 