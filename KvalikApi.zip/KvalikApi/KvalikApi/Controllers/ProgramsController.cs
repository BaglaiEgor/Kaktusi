using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProgramsController : ControllerBase
    {
        private readonly IProgramService _programService;
        public ProgramsController(IProgramService programService)
        {
            _programService = programService;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] EducationProgram program)
        {
            var created = await _programService.CreateProgramAsync(program);
            return Ok(new { created.Id, created.Title, created.Description });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var program = await _programService.GetProgramByIdAsync(id);
            if (program == null) return NotFound();
            return Ok(new { program.Id, program.Title, program.Description });
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var programs = await _programService.GetAllProgramsAsync();
            var dtos = programs.Select(p => new { p.Id, p.Title, p.Description });
            return Ok(dtos);
        }

        [HttpPut]
        public async Task<IActionResult> Update([FromBody] EducationProgram program)
        {
            // Для обновления нужен Id
            return BadRequest("Id is required for update");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _programService.DeleteProgramAsync(id);
            return NoContent();
        }
    }
} 