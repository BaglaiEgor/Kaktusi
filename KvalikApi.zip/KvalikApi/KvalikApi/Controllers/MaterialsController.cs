using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MaterialsController : ControllerBase
    {
        private readonly IMaterialService _materialService;
        public MaterialsController(IMaterialService materialService)
        {
            _materialService = materialService;
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] CreateMaterialDto materialDto)
        {
            try
            {
                Console.WriteLine($"MaterialsController.Add: получен материал - LessonId: {materialDto.LessonId}, Type: {materialDto.Type}, Content: {materialDto.Content}");
                
                var result = await _materialService.AddMaterialAsync(materialDto);
                Console.WriteLine($"MaterialsController.Add: материал успешно создан с ID: {result.Id}");
                
                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"MaterialsController.Add: ошибка - {ex.Message}");
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpGet("by-lesson/{lessonId}")]
        public async Task<IActionResult> GetByLesson(int lessonId)
        {
            var result = await _materialService.GetMaterialsByLessonAsync(lessonId);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var success = await _materialService.DeleteMaterialAsync(id);
            if (success)
                return Ok();
            return NotFound();
        }
    }
} 