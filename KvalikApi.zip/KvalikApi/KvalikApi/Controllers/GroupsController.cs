using Microsoft.AspNetCore.Mvc;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace KvalikApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GroupsController : ControllerBase
    {
        private readonly IGroupService _groupService;
        private readonly ApplicationDbContext _context;
        
        public GroupsController(IGroupService groupService, ApplicationDbContext context)
        {
            _groupService = groupService;
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Group group)
        {
            if (string.IsNullOrWhiteSpace(group.Name))
                return BadRequest("Название группы обязательно");
            var created = await _groupService.CreateGroupAsync(group);
            return Ok(created);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var group = await _groupService.GetGroupByIdDtoAsync(id);
            if (group == null) return NotFound();
            return Ok(group);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var groups = await _groupService.GetAllGroupsDtoAsync();
            return Ok(groups);
        }

        [HttpPost("{groupId}/students/{studentId}")]
        public async Task<IActionResult> AddStudent(int groupId, int studentId)
        {
            // Проверяем роль пользователя
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == studentId);
            if (user == null)
                return BadRequest("Пользователь не найден");
            
            if (user.Role == "Teacher")
                return BadRequest("Преподаватели не могут быть добавлены в группу как студенты");

            try
            {
                var gs = await _groupService.AddStudentToGroupAsync(groupId, studentId);
                return Ok(gs);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{groupId}/students/{studentId}")]
        public async Task<IActionResult> RemoveStudent(int groupId, int studentId)
        {
            await _groupService.RemoveStudentFromGroupAsync(groupId, studentId);
            return NoContent();
        }

        [HttpGet("{groupId}/schedule")]
        public async Task<IActionResult> GetSchedule(int groupId)
        {
            Console.WriteLine($"Запрос расписания для группы {groupId}");
            var schedule = await _groupService.GetScheduleAsync(groupId);
            Console.WriteLine($"Найдено уроков: {schedule?.Count() ?? 0}");
            return Ok(schedule);
        }

        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserGroups(int userId)
        {
            var groups = await _groupService.GetUserGroupsAsync(userId);
            return Ok(groups);
        }
    }
} 