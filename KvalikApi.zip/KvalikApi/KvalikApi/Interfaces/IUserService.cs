using KvalikApi.Models;
using KvalikApi.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IUserService
    {
        Task<User> RegisterAsync(string name, string email, string password, string role);
        Task<User> LoginAsync(string email, string password);
        Task<User> GetUserByIdAsync(int id);
        Task<IEnumerable<User>> GetAllUsersAsync();
        Task<UserDto> GetUserByIdDtoAsync(int id);
        Task<IEnumerable<UserDto>> GetAllUsersDtoAsync();
        Task<UserDto> LoginDtoAsync(string email, string password);
        Task<UserDto> RegisterDtoAsync(string name, string email, string password, string role);
        Task<UserDto> UpdateUserAsync(int id, string name, string email);
    }
} 