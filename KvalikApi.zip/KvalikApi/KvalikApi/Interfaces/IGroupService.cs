using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IGroupService
    {
        Task<Group> CreateGroupAsync(Group group);
        Task<GroupStudent> AddStudentToGroupAsync(int groupId, int studentId);
        Task RemoveStudentFromGroupAsync(int groupId, int studentId);
        Task<IEnumerable<LessonDto>> GetScheduleAsync(int groupId);
        Task<GroupModelDto> GetGroupByIdDtoAsync(int id);
        Task<IEnumerable<GroupModelDto>> GetAllGroupsDtoAsync();
        Task<IEnumerable<GroupModelDto>> GetUserGroupsAsync(int userId);
    }
} 