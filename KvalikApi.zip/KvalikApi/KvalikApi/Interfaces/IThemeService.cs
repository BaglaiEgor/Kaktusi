using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IThemeService
    {
        Task<Theme> CreateThemeAsync(Theme theme);
        Task<Theme> GetThemeByIdAsync(int id);
        Task<IEnumerable<Theme>> GetAllThemesAsync();
        Task<Theme> UpdateThemeAsync(Theme theme);
        Task DeleteThemeAsync(int id);
    }
} 