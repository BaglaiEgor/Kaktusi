using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IProgressService
    {
        Task<Progress> MarkLessonCompletedAsync(int studentId, int lessonId);
        Task<IEnumerable<ProgressModelDto>> GetProgressByStudentAsync(int studentId);
        Task<IEnumerable<Progress>> GetProgressByGroupAsync(int groupId);
    }
} 