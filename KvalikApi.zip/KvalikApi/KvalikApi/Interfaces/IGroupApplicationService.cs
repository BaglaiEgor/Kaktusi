using System.Collections.Generic;
using System.Threading.Tasks;
using KvalikApi.Models;

namespace KvalikApi.Interfaces
{
    public interface IGroupApplicationService
    {
        Task<GroupApplication> CreateApplicationAsync(int groupId, int studentId);
        Task<IEnumerable<GroupApplicationDto>> GetApplicationsByUserAsync(int studentId);
        Task<IEnumerable<GroupApplication>> GetApplicationsByGroupAsync(int groupId);
        Task<IEnumerable<GroupApplicationDto>> GetApplicationsByTeacherAsync(int teacherId);
        Task<GroupApplication> UpdateStatusAsync(int applicationId, string status);
        Task<GroupApplication> GetApplicationAsync(int groupId, int studentId);
    }
} 