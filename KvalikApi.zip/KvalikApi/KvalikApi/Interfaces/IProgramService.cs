using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IProgramService
    {
        Task<EducationProgram> CreateProgramAsync(EducationProgram program);
        Task<EducationProgram> GetProgramByIdAsync(int id);
        Task<IEnumerable<EducationProgram>> GetAllProgramsAsync();
        Task<EducationProgram> UpdateProgramAsync(EducationProgram program);
        Task DeleteProgramAsync(int id);
    }
} 