using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IAttendanceService
    {
        Task<Attendance> MarkAttendanceAsync(int lessonId, int studentId, bool isPresent);
        Task<IEnumerable<AttendanceDto>> GetAttendanceByLessonAsync(int lessonId);
        Task<IEnumerable<AttendanceDto>> GetAttendanceByStudentAsync(int studentId);
        Task<IEnumerable<AttendanceDto>> GetAttendanceByGroupAsync(int groupId);
    }
} 