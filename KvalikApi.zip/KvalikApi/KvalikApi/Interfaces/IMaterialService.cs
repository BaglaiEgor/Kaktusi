using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IMaterialService
    {
        Task<Material> AddMaterialAsync(CreateMaterialDto materialDto);
        Task<IEnumerable<Material>> GetMaterialsByLessonAsync(int lessonId);
        Task<bool> DeleteMaterialAsync(int id);
    }
} 