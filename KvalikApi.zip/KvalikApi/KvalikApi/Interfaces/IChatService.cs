using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface IChatService
    {
        Task<ChatMessage> SendMessageAsync(CreateChatMessageDto messageDto);
        Task<IEnumerable<ChatMessage>> GetMessagesByLessonAsync(int lessonId);
    }
} 