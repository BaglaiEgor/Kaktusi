using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface ICommentService
    {
        Task<Comment> AddCommentAsync(CreateCommentDto commentDto);
        Task<IEnumerable<Comment>> GetCommentsByLessonAsync(int lessonId);
        Task<bool> DeleteCommentAsync(int id);
    }
} 