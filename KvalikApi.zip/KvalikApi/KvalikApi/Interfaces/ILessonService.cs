using KvalikApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KvalikApi.Interfaces
{
    public interface ILessonService
    {
        Task<Lesson> CreateLessonAsync(Lesson lesson);
        Task<Lesson> GetLessonByIdAsync(int id);
        Task<IEnumerable<Lesson>> GetLessonsByGroupIdAsync(int groupId);
        Task<IEnumerable<Lesson>> GetLessonsByTeacherAsync(int teacherId);
        Task<Lesson> UpdateLessonAsync(Lesson lesson);
        Task DeleteLessonAsync(int id);
        Task<Material> AddMaterialAsync(int lessonId, Material material);
        Task<Comment> AddCommentAsync(int lessonId, Comment comment);
        Task<Attendance> MarkAttendanceAsync(int lessonId, int studentId, bool isPresent);
        Task<LessonDto> GetLessonByIdDtoAsync(int id);
    }
} 