using KvalikApi.Data;
using KvalikApi.Hubs;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddSignalR();

// Добавляем CORS для SignalR
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.WithOrigins("http://localhost:5000", "https://localhost:5001", "http://localhost:3000", 
                           "http://localhost:5149", "https://localhost:7093",
                           "http://localhost:5189", "https://localhost:7277")
               .AllowAnyHeader()
               .AllowAnyMethod()
               .AllowCredentials();
    });
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("TestDbString")), ServiceLifetime.Scoped);

builder.Services.AddScoped<KvalikApi.Interfaces.IUserService, KvalikApi.Services.UserService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IGroupService, KvalikApi.Services.GroupService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IProgramService, KvalikApi.Services.ProgramService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IThemeService, KvalikApi.Services.ThemeService>();
builder.Services.AddScoped<KvalikApi.Interfaces.ILessonService, KvalikApi.Services.LessonService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IAttendanceService, KvalikApi.Services.AttendanceService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IMaterialService, KvalikApi.Services.MaterialService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IProgressService, KvalikApi.Services.ProgressService>();
builder.Services.AddScoped<KvalikApi.Interfaces.ICommentService, KvalikApi.Services.CommentService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IChatService, KvalikApi.Services.ChatService>();
builder.Services.AddScoped<KvalikApi.Interfaces.IGroupApplicationService, KvalikApi.Services.GroupApplicationService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors();

app.UseAuthorization();

app.MapControllers();
app.MapHub<ChatHub>("/chathub");

app.Run();
