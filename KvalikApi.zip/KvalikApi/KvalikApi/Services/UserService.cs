using KvalikApi.Models;
using KvalikApi.Requests;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace KvalikApi.Services
{
    public class UserService : IUserService
    {
        private readonly ApplicationDbContext _context;
        public UserService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<User> RegisterAsync(string name, string email, string password, string role)
        {
            // Проверка валидности email
            if (!new EmailAddressAttribute().IsValid(email))
                throw new ValidationException("Некорректный email");

            // Проверка уникальности email
            var exists = await _context.Users.AnyAsync(u => u.Email == email);
            if (exists)
                throw new ValidationException("Пользователь с таким email уже существует");

            var user = new User
            {
                Name = name,
                Email = email,
                PasswordHash = password, // TODO: hash!
                Role = role
            };
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task<User> LoginAsync(string email, string password)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email && u.PasswordHash == password); // TODO: hash!
        }

        public async Task<User> GetUserByIdAsync(int id)
        {
            return await _context.Users.FindAsync(id);
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<UserDto> GetUserByIdDtoAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return null;
            
            return new UserDto
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Role = user.Role
            };
        }

        public async Task<IEnumerable<UserDto>> GetAllUsersDtoAsync()
        {
            var users = await _context.Users.ToListAsync();
            return users.Select(user => new UserDto
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Role = user.Role
            });
        }

        public async Task<UserDto> LoginDtoAsync(string email, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email && u.PasswordHash == password);
            if (user == null) return null;
            
            return new UserDto
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Role = user.Role
            };
        }

        public async Task<UserDto> RegisterDtoAsync(string name, string email, string password, string role)
        {
            // Проверка валидности email
            if (!new EmailAddressAttribute().IsValid(email))
                throw new ValidationException("Некорректный email");

            // Проверка уникальности email
            var exists = await _context.Users.AnyAsync(u => u.Email == email);
            if (exists)
                throw new ValidationException("Пользователь с таким email уже существует");

            var user = new User
            {
                Name = name,
                Email = email,
                PasswordHash = password, // TODO: hash!
                Role = role
            };
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            
            return new UserDto
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Role = user.Role
            };
        }

        public async Task<UserDto> UpdateUserAsync(int id, string name, string email)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null)
                throw new ValidationException("Пользователь не найден");

            // Проверка валидности email
            if (!new EmailAddressAttribute().IsValid(email))
                throw new ValidationException("Некорректный email");

            // Проверка уникальности email (исключая текущего пользователя)
            var exists = await _context.Users.AnyAsync(u => u.Email == email && u.Id != id);
            if (exists)
                throw new ValidationException("Пользователь с такой почтой уже зарегистрирован");

            user.Name = name;
            user.Email = email;
            
            await _context.SaveChangesAsync();
            
            return new UserDto
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Role = user.Role
            };
        }
    }
} 