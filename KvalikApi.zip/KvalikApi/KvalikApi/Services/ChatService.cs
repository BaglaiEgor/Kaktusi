using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class ChatService : IChatService
    {
        private readonly ApplicationDbContext _context;
        public ChatService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<ChatMessage> SendMessageAsync(CreateChatMessageDto messageDto)
        {
            try
            {
                Console.WriteLine($"ChatService.SendMessageAsync: создаем сообщение LessonId={messageDto.LessonId}, AuthorId={messageDto.AuthorId}");
                
                var message = new ChatMessage
                {
                    LessonId = messageDto.LessonId,
                    AuthorId = messageDto.AuthorId,
                    AuthorName = messageDto.AuthorName,
                    Text = messageDto.Text,
                    DateTime = messageDto.DateTime
                };
                
                _context.ChatMessages.Add(message);
                await _context.SaveChangesAsync();
                Console.WriteLine($"ChatService.SendMessageAsync: сообщение сохранено с Id={message.Id}");
                return message;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ChatService.SendMessageAsync: ошибка - {ex.Message}");
                throw;
            }
        }

        public async Task<IEnumerable<ChatMessage>> GetMessagesByLessonAsync(int lessonId)
        {
            return await _context.ChatMessages.Where(m => m.LessonId == lessonId).ToListAsync();
        }
    }
} 