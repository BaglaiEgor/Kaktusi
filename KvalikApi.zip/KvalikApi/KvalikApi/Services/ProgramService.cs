using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class ProgramService : IProgramService
    {
        private readonly ApplicationDbContext _context;
        public ProgramService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<EducationProgram> CreateProgramAsync(EducationProgram program)
        {
            _context.Programs.Add(program);
            await _context.SaveChangesAsync();
            return program;
        }

        public async Task<EducationProgram> GetProgramByIdAsync(int id)
        {
            return await _context.Programs.FirstOrDefaultAsync(p => p.Id == id);
        }

        public async Task<IEnumerable<EducationProgram>> GetAllProgramsAsync()
        {
            return await _context.Programs.ToListAsync();
        }

        public async Task<EducationProgram> UpdateProgramAsync(EducationProgram program)
        {
            _context.Programs.Update(program);
            await _context.SaveChangesAsync();
            return program;
        }

        public async Task DeleteProgramAsync(int id)
        {
            var program = await _context.Programs.FindAsync(id);
            if (program != null)
            {
                _context.Programs.Remove(program);
                await _context.SaveChangesAsync();
            }
        }
    }
} 