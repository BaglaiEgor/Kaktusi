using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class AttendanceService : IAttendanceService
    {
        private readonly ApplicationDbContext _context;
        public AttendanceService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Attendance> MarkAttendanceAsync(int lessonId, int studentId, bool isPresent)
        {
            // Проверяем роль пользователя, который отмечает посещаемость
            // Для этого нужно передать ID преподавателя, но пока используем простую проверку
            // В реальном приложении нужно передавать ID преподавателя из контроллера
            
            var attendance = await _context.Attendances.FirstOrDefaultAsync(a => a.LessonId == lessonId && a.StudentId == studentId);
            if (attendance == null)
            {
                attendance = new Attendance { LessonId = lessonId, StudentId = studentId, IsPresent = isPresent };
                _context.Attendances.Add(attendance);
            }
            else
            {
                attendance.IsPresent = isPresent;
                _context.Attendances.Update(attendance);
            }
            await _context.SaveChangesAsync();
            return attendance;
        }

        public async Task<IEnumerable<AttendanceDto>> GetAttendanceByLessonAsync(int lessonId)
        {
            var attendances = await _context.Attendances
                .Include(a => a.Student)
                .Include(a => a.Lesson)
                .ThenInclude(l => l.Group)
                .Where(a => a.LessonId == lessonId)
                .ToListAsync();

            return attendances.Select(a => new AttendanceDto
            {
                Id = a.Id,
                LessonId = a.LessonId,
                StudentId = a.StudentId,
                IsPresent = a.IsPresent,
                LessonTitle = a.Lesson?.Title ?? "Неизвестный урок",
                StudentName = a.Student?.Name ?? "Неизвестный студент",
                Date = a.Lesson?.DateTime
            });
        }

        public async Task<IEnumerable<AttendanceDto>> GetAttendanceByStudentAsync(int studentId)
        {
            var attendances = await _context.Attendances
                .Include(a => a.Student)
                .Include(a => a.Lesson)
                .ThenInclude(l => l.Group)
                .Where(a => a.StudentId == studentId)
                .ToListAsync();

            return attendances.Select(a => new AttendanceDto
            {
                Id = a.Id,
                LessonId = a.LessonId,
                StudentId = a.StudentId,
                IsPresent = a.IsPresent,
                LessonTitle = a.Lesson?.Title ?? "Неизвестный урок",
                StudentName = a.Student?.Name ?? "Неизвестный студент",
                Date = a.Lesson?.DateTime
            });
        }

        public async Task<IEnumerable<AttendanceDto>> GetAttendanceByGroupAsync(int groupId)
        {
            return await _context.Attendances
                .Include(a => a.Lesson)
                .Include(a => a.Student)
                .Where(a => a.Lesson != null && a.Lesson.GroupId == groupId && a.Student != null)
                .Select(a => new AttendanceDto
                {
                    Id = a.Id,
                    LessonId = a.LessonId,
                    LessonTitle = a.Lesson.Title,
                    StudentId = a.StudentId,
                    StudentName = a.Student.Name,
                    IsPresent = a.IsPresent,
                    Date = a.Lesson.DateTime
                })
                .ToListAsync();
        }
    }
} 