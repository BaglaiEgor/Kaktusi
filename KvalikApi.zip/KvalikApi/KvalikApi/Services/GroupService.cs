using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System;

namespace KvalikApi.Services
{
    public class GroupService : IGroupService
    {
        private readonly ApplicationDbContext _context;
        public GroupService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Group> CreateGroupAsync(Group group)
        {
            _context.Groups.Add(group);
            await _context.SaveChangesAsync();
            return group;
        }

        public async Task<GroupModelDto> GetGroupByIdDtoAsync(int id)
        {
            var group = await _context.Groups
                .Include(g => g.GroupStudents).ThenInclude(gs => gs.Student)
                .Include(g => g.Program)
                .Include(g => g.Teacher)
                .FirstOrDefaultAsync(g => g.Id == id);
            if (group == null) return null;

            // Получаем одобренные заявки для этой группы
            var approvedApplications = await _context.GroupApplications
                .Where(ga => ga.GroupId == id && ga.Status == "Одобрено")
                .Include(ga => ga.Student)
                .ToListAsync();

            // Получаем студентов из группы
            var groupStudents = group.GroupStudents?.Select(gs => new UserProfileModel
            {
                Id = gs.Student.Id,
                Name = gs.Student.Name,
                Email = gs.Student.Email,
                Role = gs.Student.Role
            }).ToList() ?? new List<UserProfileModel>();

            // Добавляем студентов с одобренными заявками, которых еще нет в группе
            var approvedStudents = approvedApplications
                .Where(ga => !groupStudents.Any(gs => gs.Id == ga.StudentId))
                .Select(ga => new UserProfileModel
                {
                    Id = ga.Student.Id,
                    Name = ga.Student.Name,
                    Email = ga.Student.Email,
                    Role = ga.Student.Role
                });

            var allStudents = groupStudents.Concat(approvedStudents).ToList();

            return new GroupModelDto
            {
                Id = group.Id,
                Name = group.Name,
                ProgramTitle = group.Program?.Title ?? "Без программы",
                TeacherName = group.Teacher?.Name ?? "Без преподавателя",
                Students = allStudents
            };
        }

        public async Task<IEnumerable<GroupModelDto>> GetAllGroupsDtoAsync()
        {
            var groups = await _context.Groups
                .Include(g => g.GroupStudents).ThenInclude(gs => gs.Student)
                .Include(g => g.Program)
                .Include(g => g.Teacher)
                .ToListAsync();

            var groupIds = groups.Select(g => g.Id).ToList();
            
            // Получаем все одобренные заявки для этих групп
            var approvedApplications = await _context.GroupApplications
                .Where(ga => groupIds.Contains(ga.GroupId) && ga.Status == "Одобрено")
                .Include(ga => ga.Student)
                .ToListAsync();

            return groups.Select(group => {
                // Получаем студентов из группы
                var groupStudents = group.GroupStudents?.Select(gs => new UserProfileModel
                {
                    Id = gs.Student.Id,
                    Name = gs.Student.Name,
                    Email = gs.Student.Email,
                    Role = gs.Student.Role
                }).ToList() ?? new List<UserProfileModel>();

                // Добавляем студентов с одобренными заявками, которых еще нет в группе
                var approvedStudents = approvedApplications
                    .Where(ga => ga.GroupId == group.Id)
                    .Where(ga => !groupStudents.Any(gs => gs.Id == ga.StudentId))
                    .Select(ga => new UserProfileModel
                    {
                        Id = ga.Student.Id,
                        Name = ga.Student.Name,
                        Email = ga.Student.Email,
                        Role = ga.Student.Role
                    });

                var allStudents = groupStudents.Concat(approvedStudents).ToList();

                return new GroupModelDto
                {
                    Id = group.Id,
                    Name = group.Name,
                    ProgramTitle = group.Program?.Title ?? "Без программы",
                    TeacherName = group.Teacher?.Name ?? "Без преподавателя",
                    Students = allStudents
                };
            });
        }

        public async Task<GroupStudent> AddStudentToGroupAsync(int groupId, int studentId)
        {
            var group = await _context.Groups.Include(g => g.GroupStudents).FirstOrDefaultAsync(g => g.Id == groupId);
            if (group == null)
                throw new System.Exception("Группа не найдена");
            if (group.GroupStudents.Count >= 10)
                throw new System.Exception("В группе уже максимальное количество участников (10)");
            var gs = new GroupStudent { GroupId = groupId, StudentId = studentId };
            _context.GroupStudents.Add(gs);
            await _context.SaveChangesAsync();
            return gs;
        }

        public async Task RemoveStudentFromGroupAsync(int groupId, int studentId)
        {
            var gs = await _context.GroupStudents.FirstOrDefaultAsync(x => x.GroupId == groupId && x.StudentId == studentId);
            if (gs != null)
            {
                _context.GroupStudents.Remove(gs);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<LessonDto>> GetScheduleAsync(int groupId)
        {
            try
            {
                Console.WriteLine($"Поиск уроков для группы {groupId}");
                var lessons = await _context.Lessons
                    .Where(l => l.GroupId == groupId)
                    .Include(l => l.Group)
                    .Include(l => l.Materials)
                    .Include(l => l.Comments)
                    .ThenInclude(c => c.Author)
                    .ToListAsync();

                Console.WriteLine($"Найдено уроков в БД: {lessons.Count}");
                foreach (var lesson in lessons)
                {
                    Console.WriteLine($"Урок в БД: {lesson.Title}, GroupId: {lesson.GroupId}, DateTime: {lesson.DateTime}");
                }

                var result = lessons.Select(l => new LessonDto
                {
                    Id = l.Id,
                    GroupId = l.GroupId,
                    GroupName = l.Group?.Name,
                    Title = l.Title,
                    Description = l.Description,
                    ThemeId = l.ThemeId,
                    DateTime = l.DateTime,
                    Materials = l.Materials?.Select(m => new MaterialDto
                    {
                        Id = m.Id,
                        Type = m.Type,
                        Content = m.Content
                    }).ToList() ?? new List<MaterialDto>(),
                    Comments = l.Comments?.Select(c => new CommentDto
                    {
                        Id = c.Id,
                        AuthorName = c.Author?.Name,
                        Text = c.Text,
                        DateTime = c.DateTime
                    }).ToList() ?? new List<CommentDto>()
                });

                Console.WriteLine($"Возвращаем {result.Count()} уроков");
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ОШИБКА В GetScheduleAsync: {ex}");
                throw;
            }
        }

        public async Task<IEnumerable<GroupModelDto>> GetUserGroupsAsync(int userId)
        {
            // Сначала получаем пользователя чтобы узнать его роль
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == userId);
            if (user == null) return new List<GroupModelDto>();

            if (user.Role == "Teacher")
            {
                // Для преподавателя возвращаем группы, где он является преподавателем
                var teacherGroups = await _context.Groups
                    .Where(g => g.TeacherId == userId)
                    .Include(g => g.Program)
                    .Include(g => g.Teacher)
                    .Include(g => g.GroupStudents)
                    .ThenInclude(gs => gs.Student)
                    .ToListAsync();

                // Получаем все одобренные заявки для этих групп
                var groupIds = teacherGroups.Select(g => g.Id).ToList();
                var approvedApplications = await _context.GroupApplications
                    .Where(ga => groupIds.Contains(ga.GroupId) && ga.Status == "Одобрено")
                    .Include(ga => ga.Student)
                    .ToListAsync();

                return teacherGroups.Select(group => {
                    var groupStudents = group.GroupStudents?.Select(gs => new UserProfileModel
                    {
                        Id = gs.Student.Id,
                        Name = gs.Student.Name,
                        Email = gs.Student.Email,
                        Role = gs.Student.Role
                    }).ToList() ?? new List<UserProfileModel>();

                    var approvedStudents = approvedApplications
                        .Where(ga => ga.GroupId == group.Id)
                        .Where(ga => !groupStudents.Any(gs => gs.Id == ga.StudentId))
                        .Select(ga => new UserProfileModel
                        {
                            Id = ga.Student.Id,
                            Name = ga.Student.Name,
                            Email = ga.Student.Email,
                            Role = ga.Student.Role
                        });

                    var allStudents = groupStudents.Concat(approvedStudents).ToList();

                    return new GroupModelDto
                    {
                        Id = group.Id,
                        Name = group.Name,
                        ProgramTitle = group.Program?.Title ?? "Без программы",
                        TeacherName = group.Teacher?.Name ?? "Без преподавателя",
                        Students = allStudents
                    };
                });
            }
            else
            {
                // Для студента возвращаем группы, где он является студентом
                var memberGroups = await _context.GroupStudents
                    .Where(gs => gs.StudentId == userId)
                    .Include(gs => gs.Group)
                    .ThenInclude(g => g.Program)
                    .Include(gs => gs.Group)
                    .ThenInclude(g => g.Teacher)
                    .Include(gs => gs.Group)
                    .ThenInclude(g => g.GroupStudents)
                    .ThenInclude(gs => gs.Student)
                    .Select(gs => gs.Group)
                    .ToListAsync();

                // Получаем группы, где есть одобренные заявки пользователя
                var approvedApplicationGroups = await _context.GroupApplications
                    .Where(ga => ga.StudentId == userId && ga.Status == "Одобрено")
                    .Include(ga => ga.Group)
                    .ThenInclude(g => g.Program)
                    .Include(ga => ga.Group)
                    .ThenInclude(g => g.Teacher)
                    .Include(ga => ga.Group)
                    .ThenInclude(g => g.GroupStudents)
                    .ThenInclude(gs => gs.Student)
                    .Include(ga => ga.Student)
                    .Select(ga => ga.Group)
                    .ToListAsync();

                // Объединяем и убираем дубликаты
                var allGroups = memberGroups.Union(approvedApplicationGroups, new GroupComparer()).ToList();

                // Получаем все одобренные заявки для этих групп
                var groupIds = allGroups.Select(g => g.Id).ToList();
                var approvedApplications = await _context.GroupApplications
                    .Where(ga => groupIds.Contains(ga.GroupId) && ga.Status == "Одобрено")
                    .Include(ga => ga.Student)
                    .ToListAsync();

                return allGroups.Select(group => {
                    var groupStudents = group.GroupStudents?.Select(gs => new UserProfileModel
                    {
                        Id = gs.Student.Id,
                        Name = gs.Student.Name,
                        Email = gs.Student.Email,
                        Role = gs.Student.Role
                    }).ToList() ?? new List<UserProfileModel>();

                    var approvedStudents = approvedApplications
                        .Where(ga => ga.GroupId == group.Id)
                        .Where(ga => !groupStudents.Any(gs => gs.Id == ga.StudentId))
                        .Select(ga => new UserProfileModel
                        {
                            Id = ga.Student.Id,
                            Name = ga.Student.Name,
                            Email = ga.Student.Email,
                            Role = ga.Student.Role
                        });

                    var allStudents = groupStudents.Concat(approvedStudents).ToList();

                    return new GroupModelDto
                    {
                        Id = group.Id,
                        Name = group.Name,
                        ProgramTitle = group.Program?.Title ?? "Без программы",
                        TeacherName = group.Teacher?.Name ?? "Без преподавателя",
                        Students = allStudents
                    };
                });
            }
        }
    }

    // Компаратор для убирания дубликатов групп
    public class GroupComparer : IEqualityComparer<Group>
    {
        public bool Equals(Group x, Group y)
        {
            return x.Id == y.Id;
        }

        public int GetHashCode(Group obj)
        {
            return obj.Id.GetHashCode();
        }
    }
} 