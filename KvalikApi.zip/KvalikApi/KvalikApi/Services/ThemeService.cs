using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class ThemeService : IThemeService
    {
        private readonly ApplicationDbContext _context;
        public ThemeService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Theme> CreateThemeAsync(Theme theme)
        {
            _context.Themes.Add(theme);
            await _context.SaveChangesAsync();
            return theme;
        }

        public async Task<Theme> GetThemeByIdAsync(int id)
        {
            return await _context.Themes.FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task<IEnumerable<Theme>> GetAllThemesAsync()
        {
            return await _context.Themes.ToListAsync();
        }

        public async Task<Theme> UpdateThemeAsync(Theme theme)
        {
            _context.Themes.Update(theme);
            await _context.SaveChangesAsync();
            return theme;
        }

        public async Task DeleteThemeAsync(int id)
        {
            var theme = await _context.Themes.FindAsync(id);
            if (theme != null)
            {
                _context.Themes.Remove(theme);
                await _context.SaveChangesAsync();
            }
        }
    }
} 