using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class CommentService : ICommentService
    {
        private readonly ApplicationDbContext _context;
        public CommentService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Comment> AddCommentAsync(CreateCommentDto commentDto)
        {
            try
            {
                Console.WriteLine($"CommentService.AddCommentAsync вызван");
                Console.WriteLine($"Добавляем комментарий: LessonId={commentDto.LessonId}, AuthorId={commentDto.AuthorId}, Text={commentDto.Text}");
                
                var comment = new Comment
                {
                    LessonId = commentDto.LessonId,
                    AuthorId = commentDto.AuthorId,
                    Text = commentDto.Text,
                    DateTime = commentDto.DateTime
                };
                
                _context.Comments.Add(comment);
                Console.WriteLine("Комментарий добавлен в контекст");
                
                await _context.SaveChangesAsync();
                Console.WriteLine($"Комментарий сохранен в БД с Id: {comment.Id}");
                
                return comment;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка в CommentService.AddCommentAsync: {ex.Message}");
                Console.WriteLine($"StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        public async Task<IEnumerable<Comment>> GetCommentsByLessonAsync(int lessonId)
        {
            return await _context.Comments.Where(c => c.LessonId == lessonId).ToListAsync();
        }

        public async Task<bool> DeleteCommentAsync(int id)
        {
            var comment = await _context.Comments.FindAsync(id);
            if (comment == null)
                return false;

            _context.Comments.Remove(comment);
            await _context.SaveChangesAsync();
            return true;
        }
    }
} 