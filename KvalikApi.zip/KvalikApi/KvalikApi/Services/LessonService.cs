using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class LessonService : ILessonService
    {
        private readonly ApplicationDbContext _context;
        public LessonService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Lesson> CreateLessonAsync(Lesson lesson)
        {
            _context.Lessons.Add(lesson);
            await _context.SaveChangesAsync();
            return lesson;
        }

        public async Task<Lesson> GetLessonByIdAsync(int id)
        {
            return await _context.Lessons.Include(l => l.Materials).Include(l => l.Comments).Include(l => l.ChatMessages).FirstOrDefaultAsync(l => l.Id == id);
        }

        public async Task<IEnumerable<Lesson>> GetLessonsByGroupIdAsync(int groupId)
        {
            return await _context.Lessons.Where(l => l.GroupId == groupId).ToListAsync();
        }

        public async Task<IEnumerable<Lesson>> GetLessonsByTeacherAsync(int teacherId)
        {
            return await _context.Lessons
                .Include(l => l.Group)
                .Where(l => l.Group.TeacherId == teacherId)
                .ToListAsync();
        }

        public async Task<Lesson> UpdateLessonAsync(Lesson lesson)
        {
            _context.Lessons.Update(lesson);
            await _context.SaveChangesAsync();
            return lesson;
        }

        public async Task DeleteLessonAsync(int id)
        {
            var lesson = await _context.Lessons.FindAsync(id);
            if (lesson != null)
            {
                _context.Lessons.Remove(lesson);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<Material> AddMaterialAsync(int lessonId, Material material)
        {
            material.LessonId = lessonId;
            _context.Materials.Add(material);
            await _context.SaveChangesAsync();
            return material;
        }

        public async Task<Comment> AddCommentAsync(int lessonId, Comment comment)
        {
            comment.LessonId = lessonId;
            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();
            return comment;
        }

        public async Task<Attendance> MarkAttendanceAsync(int lessonId, int studentId, bool isPresent)
        {
            var attendance = await _context.Attendances.FirstOrDefaultAsync(a => a.LessonId == lessonId && a.StudentId == studentId);
            if (attendance == null)
            {
                attendance = new Attendance { LessonId = lessonId, StudentId = studentId, IsPresent = isPresent };
                _context.Attendances.Add(attendance);
            }
            else
            {
                attendance.IsPresent = isPresent;
                _context.Attendances.Update(attendance);
            }
            await _context.SaveChangesAsync();
            return attendance;
        }

        public async Task<LessonDto> GetLessonByIdDtoAsync(int id)
        {
            var lesson = await _context.Lessons
                .Include(l => l.Materials)
                .Include(l => l.Comments).ThenInclude(c => c.Author)
                .Include(l => l.ChatMessages).ThenInclude(m => m.Author)
                .FirstOrDefaultAsync(l => l.Id == id);
            if (lesson == null) return null;
            return new LessonDto
            {
                Id = lesson.Id,
                GroupId = lesson.GroupId,
                Title = lesson.Title,
                Description = lesson.Description,
                DateTime = lesson.DateTime,
                Materials = lesson.Materials?.Select(m => new MaterialDto
                {
                    Id = m.Id,
                    Type = m.Type,
                    Content = m.Content
                }).ToList(),
                Comments = lesson.Comments?.Select(c => new CommentDto
                {
                    Id = c.Id,
                    AuthorName = c.Author?.Name,
                    Text = c.Text,
                    DateTime = c.DateTime
                }).ToList()
                //ChatMessages = lesson.ChatMessages?.Select(m => new ChatMessageDto
                //{
                //    Id = m.Id,
                //    AuthorId = m.AuthorId,
                //    AuthorName = m.Author?.Name,
                //    Text = m.Text,
                //    DateTime = m.DateTime
                //}).ToList()
            };
        }
    }
} 