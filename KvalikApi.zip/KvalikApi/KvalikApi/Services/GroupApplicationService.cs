using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KvalikApi.Data;
using KvalikApi.Interfaces;
using KvalikApi.Models;
using Microsoft.EntityFrameworkCore;

namespace KvalikApi.Services
{
    public class GroupApplicationService : IGroupApplicationService
    {
        private readonly ApplicationDbContext _context;
        public GroupApplicationService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<GroupApplication> CreateApplicationAsync(int groupId, int studentId)
        {
            // Проверяем роль пользователя
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == studentId);
            if (user == null)
                throw new System.Exception("Пользователь не найден");
            
            if (user.Role == "Teacher")
                throw new System.Exception("Преподаватели не могут подавать заявки на вступление в группы");

            // Проверка на существование заявки
            var exists = await _context.GroupApplications.AnyAsync(a => a.GroupId == groupId && a.StudentId == studentId && a.Status == "Заявка подана");
            if (exists)
                throw new System.Exception("Заявка уже подана");
            var app = new GroupApplication
            {
                GroupId = groupId,
                StudentId = studentId,
                Status = "Заявка подана"
            };
            _context.GroupApplications.Add(app);
            await _context.SaveChangesAsync();
            return app;
        }

        public async Task<IEnumerable<GroupApplicationDto>> GetApplicationsByUserAsync(int studentId)
        {
            var applications = await _context.GroupApplications
                .Include(a => a.Group)
                .ThenInclude(g => g.Program)
                .Include(a => a.Group)
                .ThenInclude(g => g.Teacher)
                .Include(a => a.Student)
                .Where(a => a.StudentId == studentId)
                .ToListAsync();
                
            return applications.Select(a => new GroupApplicationDto
            {
                Id = a.Id,
                StudentId = a.StudentId,
                GroupId = a.GroupId,
                Status = a.Status,
                CreatedAt = a.CreatedAt,
                ReviewedAt = a.ReviewedAt,
                GroupName = a.Group?.Name ?? "Неизвестная группа",
                ProgramTitle = a.Group?.Program?.Title ?? "Программа не указана",
                TeacherName = a.Group?.Teacher?.Name ?? "Преподаватель не указан",
                StudentName = a.Student?.Name ?? "Неизвестный студент"
            });
        }

        public async Task<IEnumerable<GroupApplication>> GetApplicationsByGroupAsync(int groupId)
        {
            return await _context.GroupApplications.Include(a => a.Student).Where(a => a.GroupId == groupId).ToListAsync();
        }

        public async Task<IEnumerable<GroupApplicationDto>> GetApplicationsByTeacherAsync(int teacherId)
        {
            var applications = await _context.GroupApplications
                .Include(a => a.Group)
                .ThenInclude(g => g.Program)
                .Include(a => a.Group)
                .ThenInclude(g => g.Teacher)
                .Include(a => a.Student)
                .Where(a => a.Group.TeacherId == teacherId)
                .ToListAsync();
                
            return applications.Select(a => new GroupApplicationDto
            {
                Id = a.Id,
                StudentId = a.StudentId,
                GroupId = a.GroupId,
                Status = a.Status,
                CreatedAt = a.CreatedAt,
                ReviewedAt = a.ReviewedAt,
                GroupName = a.Group?.Name ?? "Неизвестная группа",
                ProgramTitle = a.Group?.Program?.Title ?? "Программа не указана",
                TeacherName = a.Group?.Teacher?.Name ?? "Преподаватель не указан",
                StudentName = a.Student?.Name ?? "Неизвестный студент"
            });
        }

        public async Task<GroupApplication> UpdateStatusAsync(int applicationId, string status)
        {
            var app = await _context.GroupApplications.FindAsync(applicationId);
            if (app == null) throw new System.Exception("Заявка не найдена");
            
            if (status == "Approved" || status == "Одобрено")
            {
                // Проверяем, не превышает ли группа максимальное количество участников
                var group = await _context.Groups
                    .Include(g => g.GroupStudents)
                    .FirstOrDefaultAsync(g => g.Id == app.GroupId);
                
                if (group == null)
                    throw new System.Exception("Группа не найдена");
                
                // Подсчитываем общее количество участников (включая одобренные заявки)
                var approvedApplications = await _context.GroupApplications
                    .Where(ga => ga.GroupId == app.GroupId && ga.Status == "Одобрено")
                    .CountAsync();
                
                var totalParticipants = group.GroupStudents.Count + approvedApplications;
                
                if (totalParticipants >= 10)
                    throw new System.Exception("Группа уже заполнена (максимум 10 участников)");
                
                app.Status = "Одобрено";
                // Добавляем в группу, если ещё не добавлен
                var exists = await _context.GroupStudents.AnyAsync(gs => gs.GroupId == app.GroupId && gs.StudentId == app.StudentId);
                if (!exists)
                {
                    _context.GroupStudents.Add(new GroupStudent { GroupId = app.GroupId, StudentId = app.StudentId });
                }
            }
            else if (status == "Rejected" || status == "Отклонено")
            {
                app.Status = "Отклонено";
            }
            else
            {
                app.Status = status;
            }
            app.ReviewedAt = System.DateTime.UtcNow;
            await _context.SaveChangesAsync();
            return app;
        }

        public async Task<GroupApplication> GetApplicationAsync(int groupId, int studentId)
        {
            return await _context.GroupApplications.FirstOrDefaultAsync(a => a.GroupId == groupId && a.StudentId == studentId && a.Status == "Заявка подана");
        }
    }
} 