using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class MaterialService : IMaterialService
    {
        private readonly ApplicationDbContext _context;
        public MaterialService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Material> AddMaterialAsync(CreateMaterialDto materialDto)
        {
            Console.WriteLine($"MaterialService.AddMaterialAsync: начало - LessonId: {materialDto.LessonId}");
            
            // Проверяем, что урок существует
            var lesson = await _context.Lessons.FindAsync(materialDto.LessonId);
            if (lesson == null)
            {
                Console.WriteLine($"MaterialService.AddMaterialAsync: урок с ID {materialDto.LessonId} не найден");
                throw new Exception($"Урок с ID {materialDto.LessonId} не найден");
            }
            
            Console.WriteLine($"MaterialService.AddMaterialAsync: урок найден - {lesson.Title}");
            
            // Создаем новый материал из DTO
            var material = new Material
            {
                LessonId = materialDto.LessonId,
                Type = materialDto.Type,
                Content = materialDto.Content
            };
            
            _context.Materials.Add(material);
            await _context.SaveChangesAsync();
            
            Console.WriteLine($"MaterialService.AddMaterialAsync: материал сохранен с ID: {material.Id}");
            return material;
        }

        public async Task<IEnumerable<Material>> GetMaterialsByLessonAsync(int lessonId)
        {
            return await _context.Materials.Where(m => m.LessonId == lessonId).ToListAsync();
        }

        public async Task<bool> DeleteMaterialAsync(int id)
        {
            var material = await _context.Materials.FindAsync(id);
            if (material == null)
                return false;
            
            _context.Materials.Remove(material);
            await _context.SaveChangesAsync();
            return true;
        }
    }
} 