using KvalikApi.Models;
using KvalikApi.Interfaces;
using KvalikApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KvalikApi.Services
{
    public class ProgressService : IProgressService
    {
        private readonly ApplicationDbContext _context;
        public ProgressService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Progress> MarkLessonCompletedAsync(int studentId, int lessonId)
        {
            // Проверяем роль пользователя
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == studentId);
            if (user == null)
                throw new System.Exception("Пользователь не найден");
            
            if (user.Role == "Teacher")
                throw new System.Exception("Преподаватели не могут отмечать уроки как просмотренные");

            // Получаем урок
            var lesson = await _context.Lessons
                .Include(l => l.Theme)
                .FirstOrDefaultAsync(l => l.Id == lessonId);
            
            if (lesson == null)
                throw new System.Exception("Урок не найден");

            // Проверяем, что студент состоит в группе этого урока
            var isInGroup = await _context.GroupStudents
                .AnyAsync(gs => gs.StudentId == studentId && gs.GroupId == lesson.GroupId);
            
            if (!isInGroup)
                throw new System.Exception("Вы не состоите в группе этого урока");

            // Проверяем, что предыдущий урок пройден (если это не первый урок в теме)
            var previousLesson = await _context.Lessons
                .Where(l => l.ThemeId == lesson.ThemeId && l.GroupId == lesson.GroupId && l.Id < lesson.Id)
                .OrderByDescending(l => l.Id)
                .FirstOrDefaultAsync();

            if (previousLesson != null)
            {
                var previousProgress = await _context.Progresses
                    .FirstOrDefaultAsync(p => p.StudentId == studentId && p.LessonId == previousLesson.Id);
                
                if (previousProgress == null || !previousProgress.IsCompleted)
                    throw new System.Exception("Сначала нужно пройти предыдущий урок");
            }

            var progress = await _context.Progresses.FirstOrDefaultAsync(p => p.StudentId == studentId && p.LessonId == lessonId);
            if (progress == null)
            {
                progress = new Progress { 
                    StudentId = studentId, 
                    LessonId = lessonId, 
                    IsCompleted = true,
                    CompletedAt = System.DateTime.UtcNow
                };
                _context.Progresses.Add(progress);
            }
            else
            {
                progress.IsCompleted = true;
                progress.CompletedAt = System.DateTime.UtcNow;
                _context.Progresses.Update(progress);
            }
            await _context.SaveChangesAsync();
            return progress;
        }

        public async Task<IEnumerable<ProgressModelDto>> GetProgressByStudentAsync(int studentId)
        {
            // Получаем все группы пользователя
            var groupIds = await _context.GroupStudents
                .Where(gs => gs.StudentId == studentId)
                .Select(gs => gs.GroupId)
                .ToListAsync();

            // Получаем все уроки из этих групп
            var lessons = await _context.Lessons
                .Where(l => l.GroupId != null && groupIds.Contains(l.GroupId.Value))
                .Include(l => l.Group)
                .ToListAsync();

            // Получаем все записи о прогрессе пользователя
            var progresses = await _context.Progresses
                .Where(p => p.StudentId == studentId)
                .ToListAsync();

            // Формируем результат
            var result = lessons.Select(lesson => {
                var progress = progresses.FirstOrDefault(p => p.LessonId == lesson.Id);
                return new ProgressModelDto
                {
                    LessonId = lesson.Id,
                    LessonTitle = lesson.Title,
                    GroupName = lesson.Group?.Name,
                    IsCompleted = progress?.IsCompleted ?? false,
                    CompletedAt = progress?.CompletedAt
                };
            }).ToList();

            return result;
        }

        public async Task<IEnumerable<Progress>> GetProgressByGroupAsync(int groupId)
        {
            var lessonIds = await _context.Lessons.Where(l => l.GroupId == groupId).Select(l => l.Id).ToListAsync();
            return await _context.Progresses.Where(p => lessonIds.Contains(p.LessonId)).ToListAsync();
        }
    }
} 