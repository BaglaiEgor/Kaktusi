using System.ComponentModel.DataAnnotations;

namespace KvalikApi.Models
{
    public class CreateChatMessageDto
    {
        [Required]
        public int LessonId { get; set; }
        
        [Required]
        public int AuthorId { get; set; }
        
        [Required]
        public string AuthorName { get; set; }
        
        [Required]
        public string Text { get; set; }
        
        public DateTime DateTime { get; set; } = DateTime.Now;
    }
} 