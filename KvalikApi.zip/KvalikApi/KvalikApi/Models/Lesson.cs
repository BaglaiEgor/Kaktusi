using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;
using System.Collections.Generic;

namespace KvalikApi.Models
{
    public class Lesson
    {
        [Key]
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int? ThemeId { get; set; }
        [ForeignKey("ThemeId")]
        public Theme Theme { get; set; }
        public int? GroupId { get; set; }
        [ForeignKey("GroupId")]
        public Group Group { get; set; }
        public DateTime? DateTime { get; set; }
        // Навигация
        public ICollection<Material> Materials { get; set; }
        public ICollection<Comment> Comments { get; set; }
        public ICollection<ChatMessage> ChatMessages { get; set; }
        public ICollection<Attendance> Attendances { get; set; }
        public ICollection<Progress> Progresses { get; set; }
    }
} 