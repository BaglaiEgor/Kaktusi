namespace KvalikApi.Models
{
    public class CreateLessonDto
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public int ThemeId { get; set; }
        public int GroupId { get; set; }
        public DateTime DateTime { get; set; }
    }
} 