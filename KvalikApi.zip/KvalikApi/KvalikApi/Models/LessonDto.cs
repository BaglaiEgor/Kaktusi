using System;
using System.Collections.Generic;

namespace KvalikApi.Models
{
    public class LessonDto
    {
        public int Id { get; set; }
        public int? GroupId { get; set; }
        public string GroupName { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int? ThemeId { get; set; }
        public DateTime? DateTime { get; set; }
        public List<MaterialDto> Materials { get; set; }
        public List<CommentDto> Comments { get; set; }
        // public List<ChatMessageDto> ChatMessages { get; set; } // временно убрано
    }

    public class MaterialDto
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Content { get; set; }
    }

    public class CommentDto
    {
        public int Id { get; set; }
        public string AuthorName { get; set; }
        public string Text { get; set; }
        public DateTime DateTime { get; set; }
    }

    public class ChatMessageDto
    {
        public int Id { get; set; }
        public int AuthorId { get; set; }
        public string AuthorName { get; set; }
        public string Text { get; set; }
        public DateTime DateTime { get; set; }
    }
} 