using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KvalikApi.Models
{
    public class Material
    {
        [Key]
        public int Id { get; set; }
        public int LessonId { get; set; }
        [ForeignKey("LessonId")]
        public Lesson? Lesson { get; set; }
        public string Type { get; set; } = string.Empty; // text, link, video
        public string Content { get; set; } = string.Empty; // текст или ссылка
    }
} 