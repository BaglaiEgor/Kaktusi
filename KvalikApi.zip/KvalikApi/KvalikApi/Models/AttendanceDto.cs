using System;

namespace KvalikApi.Models
{
    public class AttendanceDto
    {
        public int Id { get; set; }
        public int LessonId { get; set; }
        public string LessonTitle { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public bool IsPresent { get; set; }
        public DateTime? Date { get; set; }
    }
} 