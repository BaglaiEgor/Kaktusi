using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace KvalikApi.Models
{
    public class Group
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public int ProgramId { get; set; }
        [ForeignKey("ProgramId")]
        public EducationProgram Program { get; set; }
        public int TeacherId { get; set; }
        [ForeignKey("TeacherId")]
        public User Teacher { get; set; }
        // Навигация
        public ICollection<GroupStudent> GroupStudents { get; set; }
        public ICollection<Lesson> Lessons { get; set; }
        public ICollection<Attendance> Attendances { get; set; }
    }
} 