using System.Collections.Generic;

namespace KvalikApi.Models
{
    public class GroupModelDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ProgramTitle { get; set; }
        public string TeacherName { get; set; }
        public List<UserProfileModel> Students { get; set; } = new List<UserProfileModel>();
    }

    public class UserProfileModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
    }
} 