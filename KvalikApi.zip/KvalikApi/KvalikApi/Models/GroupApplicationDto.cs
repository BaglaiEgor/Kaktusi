using System;

namespace KvalikApi.Models
{
    public class GroupApplicationDto
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int GroupId { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ReviewedAt { get; set; }
        
        // Дополнительные свойства для отображения
        public string GroupName { get; set; }
        public string ProgramTitle { get; set; }
        public string TeacherName { get; set; }
        public string StudentName { get; set; }
    }
} 