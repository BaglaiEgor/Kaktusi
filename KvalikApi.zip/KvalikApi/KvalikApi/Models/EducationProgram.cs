using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace KvalikApi.Models
{
    public class EducationProgram
    {
        [Key]
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        // Навигация
        public ICollection<Theme> Themes { get; set; }
        public ICollection<Group> Groups { get; set; }
    }
}