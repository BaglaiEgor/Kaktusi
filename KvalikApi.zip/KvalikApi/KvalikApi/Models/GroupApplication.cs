using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KvalikApi.Models
{
    public class GroupApplication
    {
        [Key]
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int GroupId { get; set; }
        public string Status { get; set; } // "Pending", "Approved", "Rejected"
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? ReviewedAt { get; set; }
        [ForeignKey("StudentId")]
        public User Student { get; set; }
        [ForeignKey("GroupId")]
        public Group Group { get; set; }
    }
} 