using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace KvalikApi.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }
        [MaxLength(100)]
        [EmailAddress]
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        [MaxLength(20)]
        public string Role { get; set; } // Student, Teacher, Admin
        // Навигация
        // public ICollection<Group> Groups { get; set; }
        public ICollection<GroupStudent> GroupStudents { get; set; }
        public ICollection<Attendance> Attendances { get; set; }
        public ICollection<Progress> Progresses { get; set; }
        public ICollection<Comment> Comments { get; set; }
        public ICollection<ChatMessage> ChatMessages { get; set; }
    }
} 