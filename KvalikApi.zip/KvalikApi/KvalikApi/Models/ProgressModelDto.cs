using System;

namespace KvalikApi.Models
{
    public class ProgressModelDto
    {
        public int LessonId { get; set; }
        public string LessonTitle { get; set; }
        public string GroupName { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? CompletedAt { get; set; }
    }
} 