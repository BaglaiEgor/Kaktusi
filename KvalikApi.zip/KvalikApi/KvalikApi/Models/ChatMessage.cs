using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;

namespace KvalikApi.Models
{
    public class ChatMessage
    {
        [Key]
        public int Id { get; set; }
        public int LessonId { get; set; }
        [ForeignKey("LessonId")]
        public Lesson Lesson { get; set; }
        public int AuthorId { get; set; }
        [ForeignKey("AuthorId")]
        public User Author { get; set; }
        public string AuthorName { get; set; }
        public string Text { get; set; }
        public DateTime DateTime { get; set; }
    }
} 