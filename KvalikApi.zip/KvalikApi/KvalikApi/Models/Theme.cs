using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace KvalikApi.Models
{
    public class Theme
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(200)]
        public string Title { get; set; }
        public string Description { get; set; }
        public int ProgramId { get; set; }
        [ForeignKey("ProgramId")]
        public EducationProgram Program { get; set; }
        // Навигация
        public ICollection<Lesson> Lessons { get; set; }
    }
} 