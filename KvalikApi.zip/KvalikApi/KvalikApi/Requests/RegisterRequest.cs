using System.ComponentModel.DataAnnotations;

namespace KvalikApi.Requests
{
    public class RegisterRequest
    {
        [MaxLength(100)]
        public string Name { get; set; }
        [MaxLength(100)]
        public string Email { get; set; }
        [MinLength(6)]
        public string Password { get; set; }
        [MaxLength(20)]
        public string Role { get; set; }
    }
} 