using System.ComponentModel.DataAnnotations;

namespace KvalikApi.Requests
{
    public class LoginRequest
    {
        [MaxLength(100)]
        public string Email { get; set; }
        public string Password { get; set; }
    }
} 