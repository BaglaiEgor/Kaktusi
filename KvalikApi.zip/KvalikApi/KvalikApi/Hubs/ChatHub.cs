using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace KvalikApi.Hubs
{
    public class ChatHub : Hub
    {
        // Вход в чат урока (группы по уроку)
        public async Task JoinLessonChat(int lessonId)
        {
            Console.WriteLine($"JoinLessonChat: пользователь {Context.ConnectionId} присоединяется к чату урока {lessonId}");
            await Groups.AddToGroupAsync(Context.ConnectionId, $"lesson_{lessonId}");
            Console.WriteLine($"JoinLessonChat: пользователь {Context.ConnectionId} успешно добавлен в группу lesson_{lessonId}");
        }

        // Отправка сообщения в чат урока
        public async Task SendMessage(int lessonId, int userId, string userName, string message)
        {
            Console.WriteLine($"SendMessage: отправка сообщения от {userName} (ID: {userId}) в чат урока {lessonId}: {message}");
            await Clients.Group($"lesson_{lessonId}").SendAsync("ReceiveMessage", userId, userName, message, System.DateTime.Now);
            Console.WriteLine($"SendMessage: сообщение отправлено в группу lesson_{lessonId}");
        }

        public override async Task OnConnectedAsync()
        {
            Console.WriteLine($"OnConnectedAsync: новое подключение {Context.ConnectionId}");
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            Console.WriteLine($"OnDisconnectedAsync: отключение {Context.ConnectionId}, ошибка: {exception?.Message}");
            await base.OnDisconnectedAsync(exception);
        }
    }
} 